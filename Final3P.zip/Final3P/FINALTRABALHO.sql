-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: Notas
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alunos`
--

DROP TABLE IF EXISTS `alunos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alunos` (
  `alunos_id` int NOT NULL AUTO_INCREMENT,
  `alunos_matriculados` tinyint(1) DEFAULT NULL,
  `alunos_sala` varchar(40) DEFAULT NULL,
  `alunos_turma` varchar(55) DEFAULT NULL,
  `qtd_disciplinas` int DEFAULT NULL,
  `fk_alunos_usuarios_id` int DEFAULT NULL,
  PRIMARY KEY (`alunos_id`),
  KEY `FK_alunos_2` (`fk_alunos_usuarios_id`),
  CONSTRAINT `FK_alunos_2` FOREIGN KEY (`fk_alunos_usuarios_id`) REFERENCES `usuarios` (`usuarios_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alunos`
--

LOCK TABLES `alunos` WRITE;
/*!40000 ALTER TABLE `alunos` DISABLE KEYS */;
INSERT INTO `alunos` VALUES (1,1,'sala 2','lola',7,1),(3,1,'5 p','sistema periodo',5,3);
/*!40000 ALTER TABLE `alunos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boletins`
--

DROP TABLE IF EXISTS `boletins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boletins` (
  `boletins_id` int NOT NULL AUTO_INCREMENT,
  `fk_boletins_notas_id` int DEFAULT NULL,
  `fk_boletins_frequencias_id` int DEFAULT NULL,
  `fk_boletins_alunos_id` int DEFAULT NULL,
  PRIMARY KEY (`boletins_id`),
  KEY `FK_boletins_2` (`fk_boletins_notas_id`),
  KEY `FK_boletins_3` (`fk_boletins_frequencias_id`),
  KEY `FK_boletins_4` (`fk_boletins_alunos_id`),
  CONSTRAINT `FK_boletins_2` FOREIGN KEY (`fk_boletins_notas_id`) REFERENCES `notas` (`notas_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_boletins_3` FOREIGN KEY (`fk_boletins_frequencias_id`) REFERENCES `frequencias` (`frequencias_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_boletins_4` FOREIGN KEY (`fk_boletins_alunos_id`) REFERENCES `alunos` (`alunos_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boletins`
--

LOCK TABLES `boletins` WRITE;
/*!40000 ALTER TABLE `boletins` DISABLE KEYS */;
/*!40000 ALTER TABLE `boletins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diarios`
--

DROP TABLE IF EXISTS `diarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diarios` (
  `diarios_id` int NOT NULL AUTO_INCREMENT,
  `diarios_local` varchar(45) DEFAULT NULL,
  `diarios_disciplinas` varchar(55) DEFAULT NULL,
  `qtd_alunos` int DEFAULT NULL,
  `fk_diarios_professores_id` int DEFAULT NULL,
  `fk_diarios_alunos_id` int DEFAULT NULL,
  PRIMARY KEY (`diarios_id`),
  KEY `FK_diarios_2` (`fk_diarios_professores_id`),
  KEY `FK_diarios_3` (`fk_diarios_alunos_id`),
  CONSTRAINT `FK_diarios_2` FOREIGN KEY (`fk_diarios_professores_id`) REFERENCES `professores` (`professores_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_diarios_3` FOREIGN KEY (`fk_diarios_alunos_id`) REFERENCES `alunos` (`alunos_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diarios`
--

LOCK TABLES `diarios` WRITE;
/*!40000 ALTER TABLE `diarios` DISABLE KEYS */;
INSERT INTO `diarios` VALUES (3,'sala1','11',11,1,1),(4,'sala 8','calculo',74,4,3);
/*!40000 ALTER TABLE `diarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `frequencias`
--

DROP TABLE IF EXISTS `frequencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `frequencias` (
  `frequencias_id` int NOT NULL AUTO_INCREMENT,
  `total_aulas` int DEFAULT NULL,
  `aulas_ministradas` int DEFAULT NULL,
  `frequencias_faltas` int DEFAULT NULL,
  `prctg_presenca` int DEFAULT NULL,
  `frequencias_disciplinas` varchar(75) DEFAULT NULL,
  `fk_frequencias_professores_id` int DEFAULT NULL,
  `fk_frequencias_alunos_id` int DEFAULT NULL,
  PRIMARY KEY (`frequencias_id`),
  KEY `FK_frequencias_2` (`fk_frequencias_professores_id`),
  KEY `FK_frequencias_3` (`fk_frequencias_alunos_id`),
  CONSTRAINT `FK_frequencias_2` FOREIGN KEY (`fk_frequencias_professores_id`) REFERENCES `professores` (`professores_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_frequencias_3` FOREIGN KEY (`fk_frequencias_alunos_id`) REFERENCES `alunos` (`alunos_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `frequencias`
--

LOCK TABLES `frequencias` WRITE;
/*!40000 ALTER TABLE `frequencias` DISABLE KEYS */;
INSERT INTO `frequencias` VALUES (2,72,4,0,100,'matematica',1,1),(5,72,5,5,0,'Calculo',4,3),(6,72,4,4,0,'matematica',1,1),(7,74,5,0,100,'matematica',4,3);
/*!40000 ALTER TABLE `frequencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instituicao`
--

DROP TABLE IF EXISTS `instituicao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instituicao` (
  `instituicao_id` int NOT NULL AUTO_INCREMENT,
  `instituicao_nome` varchar(255) DEFAULT NULL,
  `instituicao_endereco` varchar(75) DEFAULT NULL,
  `instituicao_cidade` varchar(75) DEFAULT NULL,
  `instituicao_uf` char(2) DEFAULT NULL,
  `instituicao_escolaridade` varchar(75) DEFAULT NULL,
  `instituicao_nivel` int DEFAULT NULL,
  PRIMARY KEY (`instituicao_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instituicao`
--

LOCK TABLES `instituicao` WRITE;
/*!40000 ALTER TABLE `instituicao` DISABLE KEYS */;
INSERT INTO `instituicao` VALUES (1,'if goiano','go-154','ceres','GO','superior',5),(2,'a','a','a','aa','aa',7),(4,'if goiano','rua 90','ceres','GO','superioro',7);
/*!40000 ALTER TABLE `instituicao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matriculas`
--

DROP TABLE IF EXISTS `matriculas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matriculas` (
  `matriculas_id` int NOT NULL AUTO_INCREMENT,
  `matriculas_data_inicio` varchar(12) DEFAULT NULL,
  `matriculas_data_fim` varchar(12) DEFAULT NULL,
  `qtd_tempo` varchar(15) DEFAULT NULL,
  `fk_matricula_instituicao_id` int DEFAULT NULL,
  `fk_matricula_alunos_id` int DEFAULT NULL,
  PRIMARY KEY (`matriculas_id`),
  KEY `FK_matriculas_2` (`fk_matricula_instituicao_id`),
  KEY `FK_matriculas_3` (`fk_matricula_alunos_id`),
  CONSTRAINT `FK_matriculas_2` FOREIGN KEY (`fk_matricula_instituicao_id`) REFERENCES `instituicao` (`instituicao_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_matriculas_3` FOREIGN KEY (`fk_matricula_alunos_id`) REFERENCES `alunos` (`alunos_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matriculas`
--

LOCK TABLES `matriculas` WRITE;
/*!40000 ALTER TABLE `matriculas` DISABLE KEYS */;
INSERT INTO `matriculas` VALUES (1,'2024-03-05','2027-12-20','48',1,1),(2,'2001','2002','12',1,1),(5,'10/10/2000','10/10/2001','12',4,3);
/*!40000 ALTER TABLE `matriculas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas`
--

DROP TABLE IF EXISTS `notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas` (
  `notas_id` int NOT NULL AUTO_INCREMENT,
  `nota_um` decimal(5,2) DEFAULT NULL,
  `nota_dois` decimal(5,2) DEFAULT NULL,
  `nota_tres` decimal(5,2) DEFAULT NULL,
  `nota_quatro` decimal(5,2) DEFAULT NULL,
  `nota_media` decimal(5,2) DEFAULT NULL,
  `nota_disciplina` varchar(75) DEFAULT NULL,
  `fk_notas_alunos_id` int DEFAULT NULL,
  `fk_notas_professores_id` int DEFAULT NULL,
  PRIMARY KEY (`notas_id`),
  KEY `FK_notas_2` (`fk_notas_alunos_id`),
  KEY `FK_notas_3` (`fk_notas_professores_id`),
  CONSTRAINT `FK_notas_2` FOREIGN KEY (`fk_notas_alunos_id`) REFERENCES `alunos` (`alunos_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_notas_3` FOREIGN KEY (`fk_notas_professores_id`) REFERENCES `professores` (`professores_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas`
--

LOCK TABLES `notas` WRITE;
/*!40000 ALTER TABLE `notas` DISABLE KEYS */;
INSERT INTO `notas` VALUES (10,2.00,2.00,2.00,2.00,10.00,'alskdsa',1,1),(11,15.00,15.00,7.00,7.00,11.00,'Calculo',3,4);
/*!40000 ALTER TABLE `notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professores`
--

DROP TABLE IF EXISTS `professores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `professores` (
  `professores_id` int NOT NULL AUTO_INCREMENT,
  `professores_disciplina` varchar(55) DEFAULT NULL,
  `professores_turma` varchar(25) DEFAULT NULL,
  `professores_titularidade` varchar(45) DEFAULT NULL,
  `fk_professores_usuarios_id` int DEFAULT NULL,
  PRIMARY KEY (`professores_id`),
  KEY `FK_professores_2` (`fk_professores_usuarios_id`),
  CONSTRAINT `FK_professores_2` FOREIGN KEY (`fk_professores_usuarios_id`) REFERENCES `usuarios` (`usuarios_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professores`
--

LOCK TABLES `professores` WRITE;
/*!40000 ALTER TABLE `professores` DISABLE KEYS */;
INSERT INTO `professores` VALUES (1,'ma','kola','mestrado',2),(4,'banco de dados','sala 6','mestrado',6);
/*!40000 ALTER TABLE `professores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `usuarios_id` int NOT NULL AUTO_INCREMENT,
  `usuarios_nome` varchar(255) DEFAULT NULL,
  `usuarios_sexo` char(1) DEFAULT NULL,
  `usuarios_endereco` varchar(75) DEFAULT NULL,
  `usuarios_cpf` varchar(15) DEFAULT NULL,
  `usuarios_nascimento` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`usuarios_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'m','m','m','m','m'),(2,'Jonatas','M','rua 20','90909090909','1976-09-08'),(3,'André','M','Rua 54','222.222.222-22','09/09/2009'),(4,'Dheniel Rodrigues Luis','M','rua LT','333.333.333-33','07/03/2006'),(6,'pedro','m','rua 90','999.999.999-99','10/09/2009');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-09 19:55:15
