CREATE DATABASE Notas;
use Notas;
/* ModelagemLogica: */
drop database Notas;
CREATE TABLE usuarios (
    usuarios_id INT PRIMARY KEY AUTO_INCREMENT,
    usuarios_nome VARCHAR(255) NOT NULL,
    usuarios_sexo CHAR(1) NOT NULL,
    usuarios_endereco VARCHAR(75) NOT NULL,
    usuarios_cpf VARCHAR(15) NOT NULL,
    usuarios_nascimento VARCHAR(10) NOT NULL
);

CREATE TABLE alunos (
    alunos_id INT PRIMARY KEY auto_increment,
    alunos_matriculados BOOLEAN NOT NULL,
    alunos_sala VARCHAR(40),
    alunos_turma VARCHAR(55),
    qtd_disciplinas INT,
    fk_alunos_usuarios_id INT,
    fk_alunos_matriculas_id INT
);

CREATE TABLE professores (
    professores_id INT PRIMARY KEY auto_increment,
    professores_disciplina VARCHAR(55),
    professores_turma VARCHAR(25),
    professores_titularidade VARCHAR(45),
    fk_professores_usuarios_id INT
);

CREATE TABLE diarios (
    diarios_id INT PRIMARY KEY auto_increment,
    diarios_local VARCHAR(45),
    diarios_disciplinas VARCHAR(55),
    qtd_alunos INT,
    fk_diarios_professores_id INT,
    fk_diarios_alunos_id INT
);

CREATE TABLE notas (
    notas_id INT PRIMARY KEY auto_increment,
    primeira_nota DECIMAL(3,2),
    segunda_nota DECIMAL(3,2),
    terceira_nota DECIMAL(3,2),
    quarta_nota DECIMAL(3,2),
    notas_media DECIMAL(3,2),
    fk_notas_alunos_id INT,
    fk_notas_professores_id INT
);

CREATE TABLE frequencias (
    frequencias_id INT PRIMARY KEY auto_increment,
    total_aulas INT,
    aulas_ministradas INT,
    frequencias_faltas INT,
    prctg_presenca DECIMAL(3,2),
    fk_frequencias_professores_id INT,
    fk_frequencias_alunos_id INT
);

CREATE TABLE boletins (
    boletins_id INT PRIMARY KEY auto_increment,
    boletins_situacao VARCHAR(25),
    boletins_semestres VARCHAR(25),
    boletins_media DECIMAL(3,2),
    indice_rendimento_aluno DECIMAL(3,2),
    fk_boletins_notas_id INT,
    fk_boletins_frequencias_id INT,
    fk_boletins_alunos_id INT
);

CREATE TABLE matriculas (
    matriculas_id INT PRIMARY KEY auto_increment,
    matriculas_data_inicio VARCHAR(12),
    matriculas_data_fim VARCHAR(12),
    qtd_tempo VARCHAR(15),
    fk_matricula_instituicao_id INT
);

CREATE TABLE instituicao (
    instituicao_id INT PRIMARY KEY auto_increment,
    insituicao_nome VARCHAR(255),
    insituicao_endereco VARCHAR(75),
    instituicao_cidade VARCHAR(75),
    insituicao_uf CHAR(2),
    insituicao_escolaridade VARCHAR(75),
    instituicao_nivel INT
);
 
ALTER TABLE alunos ADD CONSTRAINT FK_alunos_2
    FOREIGN KEY (fk_alunos_usuarios_id)
    REFERENCES usuarios (usuarios_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE alunos ADD CONSTRAINT FK_alunos_3
    FOREIGN KEY (fk_alunos_matriculas_id)
    REFERENCES matriculas (matriculas_id)
    ON DELETE RESTRICT;
 
ALTER TABLE professores ADD CONSTRAINT FK_professores_2
    FOREIGN KEY (fk_professores_usuarios_id)
    REFERENCES usuarios (usuarios_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE diarios ADD CONSTRAINT FK_diarios_2
    FOREIGN KEY (fk_diarios_professores_id)
    REFERENCES professores (professores_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE diarios ADD CONSTRAINT FK_diarios_3
    FOREIGN KEY (fk_diarios_alunos_id)
    REFERENCES alunos (alunos_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE notas ADD CONSTRAINT FK_notas_2
    FOREIGN KEY (fk_notas_alunos_id)
    REFERENCES alunos (alunos_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE notas ADD CONSTRAINT FK_notas_3
    FOREIGN KEY (fk_notas_professores_id)
    REFERENCES professores (professores_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE frequencias ADD CONSTRAINT FK_frequencias_2
    FOREIGN KEY (fk_frequencias_professores_id)
    REFERENCES professores (professores_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE frequencias ADD CONSTRAINT FK_frequencias_3
    FOREIGN KEY (fk_frequencias_alunos_id)
    REFERENCES alunos (alunos_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE boletins ADD CONSTRAINT FK_boletins_2
    FOREIGN KEY (fk_boletins_notas_id)
    REFERENCES notas (notas_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE boletins ADD CONSTRAINT FK_boletins_3
    FOREIGN KEY (fk_boletins_frequencias_id)
    REFERENCES frequencias (frequencias_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE boletins ADD CONSTRAINT FK_boletins_4
    FOREIGN KEY (fk_boletins_alunos_id)
    REFERENCES alunos (alunos_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
 
ALTER TABLE matriculas ADD CONSTRAINT FK_matriculas_2
    FOREIGN KEY (fk_matricula_instituicao_id)
    REFERENCES instituicao (instituicao_id)
    ON DELETE RESTRICT ON UPDATE CASCADE;
