### [Netbeans](https://netbeans.org)

#### Installing the latest release

Download the latest [latest release](https://github.com/dracula/netbeans/releases/latest/download/dracula-theme-for-netbeans.zip).

#### Activating theme

1. Start Netbeans
2. Navigate to theme import dialog: `Tools > Options > Fonts & Colors > Import..`
3. Click `Browse...` and select the `.zip` file downloaded from the release page and then click `Ok`
4. Ensure `All` option is checked and then click `Ok`

The Dracula for Netbeans looks best when combined with [Darcula LAF](https://github.com/Revivius/nb-darcula).
