-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: Suap
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alunos`
--

DROP TABLE IF EXISTS `alunos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alunos` (
  `alunos_id` int NOT NULL AUTO_INCREMENT,
  `alunos_matriculados` tinyint(1) NOT NULL,
  `alunos_sala` varchar(40) DEFAULT NULL,
  `alunos_turma` varchar(55) DEFAULT NULL,
  `qtd_disciplinas` int DEFAULT NULL,
  `fk_alunos_usuarios_id` int DEFAULT NULL,
  PRIMARY KEY (`alunos_id`),
  KEY `FK_alunos_2` (`fk_alunos_usuarios_id`),
  CONSTRAINT `FK_alunos_2` FOREIGN KEY (`fk_alunos_usuarios_id`) REFERENCES `usuarios` (`usuarios_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alunos`
--

LOCK TABLES `alunos` WRITE;
/*!40000 ALTER TABLE `alunos` DISABLE KEYS */;
/*!40000 ALTER TABLE `alunos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boletins`
--

DROP TABLE IF EXISTS `boletins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boletins` (
  `boletins_id` int NOT NULL AUTO_INCREMENT,
  `boletins_situacao` varchar(25) DEFAULT NULL,
  `boletins_semestres` varchar(25) DEFAULT NULL,
  `boletins_media` decimal(3,2) DEFAULT NULL,
  `indice_rendimento_aluno` decimal(3,2) DEFAULT NULL,
  `fk_boletins_notas_id` int DEFAULT NULL,
  `fk_boletins_frequencias_id` int DEFAULT NULL,
  `fk_boletins_alunos_id` int DEFAULT NULL,
  PRIMARY KEY (`boletins_id`),
  KEY `FK_boletins_2` (`fk_boletins_notas_id`),
  KEY `FK_boletins_3` (`fk_boletins_frequencias_id`),
  KEY `FK_boletins_4` (`fk_boletins_alunos_id`),
  CONSTRAINT `FK_boletins_2` FOREIGN KEY (`fk_boletins_notas_id`) REFERENCES `notas` (`notas_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_boletins_3` FOREIGN KEY (`fk_boletins_frequencias_id`) REFERENCES `frequencias` (`frequencias_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_boletins_4` FOREIGN KEY (`fk_boletins_alunos_id`) REFERENCES `alunos` (`alunos_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boletins`
--

LOCK TABLES `boletins` WRITE;
/*!40000 ALTER TABLE `boletins` DISABLE KEYS */;
/*!40000 ALTER TABLE `boletins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diarios`
--

DROP TABLE IF EXISTS `diarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diarios` (
  `diarios_id` int NOT NULL AUTO_INCREMENT,
  `diarios_local` varchar(45) DEFAULT NULL,
  `diarios_disciplinas` varchar(55) DEFAULT NULL,
  `qtd_alunos` int DEFAULT NULL,
  `fk_diarios_professores_id` int DEFAULT NULL,
  `fk_diarios_alunos_id` int DEFAULT NULL,
  PRIMARY KEY (`diarios_id`),
  KEY `FK_diarios_2` (`fk_diarios_professores_id`),
  KEY `FK_diarios_3` (`fk_diarios_alunos_id`),
  CONSTRAINT `FK_diarios_2` FOREIGN KEY (`fk_diarios_professores_id`) REFERENCES `professores` (`professores_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_diarios_3` FOREIGN KEY (`fk_diarios_alunos_id`) REFERENCES `alunos` (`alunos_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diarios`
--

LOCK TABLES `diarios` WRITE;
/*!40000 ALTER TABLE `diarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `diarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `frequencias`
--

DROP TABLE IF EXISTS `frequencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `frequencias` (
  `frequencias_id` int NOT NULL AUTO_INCREMENT,
  `total_aulas` int DEFAULT NULL,
  `aulas_ministradas` int DEFAULT NULL,
  `frequencias_faltas` int DEFAULT NULL,
  `prctg_presenca` decimal(3,2) DEFAULT NULL,
  `fk_frequencias_professores_id` int DEFAULT NULL,
  `fk_frequencias_alunos_id` int DEFAULT NULL,
  PRIMARY KEY (`frequencias_id`),
  KEY `FK_frequencias_2` (`fk_frequencias_professores_id`),
  KEY `FK_frequencias_3` (`fk_frequencias_alunos_id`),
  CONSTRAINT `FK_frequencias_2` FOREIGN KEY (`fk_frequencias_professores_id`) REFERENCES `professores` (`professores_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_frequencias_3` FOREIGN KEY (`fk_frequencias_alunos_id`) REFERENCES `alunos` (`alunos_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `frequencias`
--

LOCK TABLES `frequencias` WRITE;
/*!40000 ALTER TABLE `frequencias` DISABLE KEYS */;
/*!40000 ALTER TABLE `frequencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instituicao`
--

DROP TABLE IF EXISTS `instituicao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instituicao` (
  `instituicao_id` int NOT NULL AUTO_INCREMENT,
  `insituicao_nome` varchar(255) DEFAULT NULL,
  `insituicao_endereco` varchar(75) DEFAULT NULL,
  `instituicao_cidade` varchar(75) DEFAULT NULL,
  `insituicao_uf` char(2) DEFAULT NULL,
  `insituicao_escolaridade` varchar(75) DEFAULT NULL,
  `instituicao_nivel` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`instituicao_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instituicao`
--

LOCK TABLES `instituicao` WRITE;
/*!40000 ALTER TABLE `instituicao` DISABLE KEYS */;
/*!40000 ALTER TABLE `instituicao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matriculas`
--

DROP TABLE IF EXISTS `matriculas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matriculas` (
  `matriculas_id` int NOT NULL AUTO_INCREMENT,
  `matriculas_data_inicio` varchar(12) DEFAULT NULL,
  `matriculas_data_fim` varchar(12) DEFAULT NULL,
  `qtd_tempo` varchar(15) DEFAULT NULL,
  `fk_matricula_instituicao_id` int DEFAULT NULL,
  `fk_matriculas_alunos_id` int DEFAULT NULL,
  PRIMARY KEY (`matriculas_id`),
  KEY `FK_matriculas_2` (`fk_matricula_instituicao_id`),
  KEY `FK_matriculas_3` (`fk_matriculas_alunos_id`),
  CONSTRAINT `FK_matriculas_2` FOREIGN KEY (`fk_matricula_instituicao_id`) REFERENCES `instituicao` (`instituicao_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_matriculas_3` FOREIGN KEY (`fk_matriculas_alunos_id`) REFERENCES `alunos` (`alunos_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matriculas`
--

LOCK TABLES `matriculas` WRITE;
/*!40000 ALTER TABLE `matriculas` DISABLE KEYS */;
/*!40000 ALTER TABLE `matriculas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas`
--

DROP TABLE IF EXISTS `notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas` (
  `notas_id` int NOT NULL AUTO_INCREMENT,
  `primeira_nota` decimal(3,2) DEFAULT NULL,
  `segunda_nota` decimal(3,2) DEFAULT NULL,
  `terceira_nota` decimal(3,2) DEFAULT NULL,
  `quarta_nota` decimal(3,2) DEFAULT NULL,
  `notas_media` decimal(3,2) DEFAULT NULL,
  `fk_notas_alunos_id` int DEFAULT NULL,
  `fk_notas_professores_id` int DEFAULT NULL,
  PRIMARY KEY (`notas_id`),
  KEY `FK_notas_2` (`fk_notas_alunos_id`),
  KEY `FK_notas_3` (`fk_notas_professores_id`),
  CONSTRAINT `FK_notas_2` FOREIGN KEY (`fk_notas_alunos_id`) REFERENCES `alunos` (`alunos_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_notas_3` FOREIGN KEY (`fk_notas_professores_id`) REFERENCES `professores` (`professores_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas`
--

LOCK TABLES `notas` WRITE;
/*!40000 ALTER TABLE `notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professores`
--

DROP TABLE IF EXISTS `professores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `professores` (
  `professores_id` int NOT NULL AUTO_INCREMENT,
  `professores_disciplina` varchar(55) DEFAULT NULL,
  `professores_turma` varchar(25) DEFAULT NULL,
  `professores_titularidade` varchar(45) DEFAULT NULL,
  `fk_professores_usuarios_id` int DEFAULT NULL,
  PRIMARY KEY (`professores_id`),
  KEY `FK_professores_2` (`fk_professores_usuarios_id`),
  CONSTRAINT `FK_professores_2` FOREIGN KEY (`fk_professores_usuarios_id`) REFERENCES `usuarios` (`usuarios_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professores`
--

LOCK TABLES `professores` WRITE;
/*!40000 ALTER TABLE `professores` DISABLE KEYS */;
/*!40000 ALTER TABLE `professores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `usuarios_id` int NOT NULL,
  `usuarios_nome` varchar(255) NOT NULL,
  `usuarios_sexo` char(1) NOT NULL,
  `usuarios_endereco` varchar(75) NOT NULL,
  `usuarios_cpf` varchar(15) NOT NULL,
  `usuarios_nascimento` varchar(10) NOT NULL,
  PRIMARY KEY (`usuarios_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-15 22:25:09
